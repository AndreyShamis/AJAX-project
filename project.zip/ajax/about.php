<h1>About</h1>

<h2>Uses</h2>
<ul>
<li>User registration</li>
<li>Admin page for user controll</li>
<li>Mail confirmation of registration(use smtp)</li>  
</ul>

<h2>Developers</h2>
<ul>
<li>Ilia Gaysinsky</li>
<li>Andrey Shamis</li>
</ul>