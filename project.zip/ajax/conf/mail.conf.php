<?php
    //  Set here your mail settings

    $mail_host      =  "smtp.gmail.com";        //  mail host
    $mail_userName  =  "ajaxweb2012@gmail.com"; //  user name for SMTP login
    $mail_password  =  "polkalol22";            //  password
    $mail_from      =  "ajaxweb2012@gmail.com"; //  from
    $mail_fromName  =  "Dont reply" ;           //  From Name


?>