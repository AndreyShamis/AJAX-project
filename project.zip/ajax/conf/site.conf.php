<?php



    $siteURL =   "http://werdpc.dyndns.org/ajax/";

    
	/*        ************************************************************
    This mail string will be included in sended mail to user for comlitite
	the registration. */
    $siteMailURL = $siteURL . "?p=confirm&amp;confirmCode=[#confirmCode]";

?>