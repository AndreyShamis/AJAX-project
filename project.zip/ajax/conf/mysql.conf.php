<?php

    //  Here provide your information for MySQL connection
    $db_host = "localhost";     //  host
    $db_user = "ajax";          //  User to database
    $db_pass = "polkalol";      //  Password
    $db_db   = "db_ajax";       //  DATA base name


?>